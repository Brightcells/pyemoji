from pyemoji.main import (
    encode,
    decode,
    replace,
    entities,
)
